const axios = require("axios");

exports.handler = async (event) => {
    try {
        const backendURL = "http://44.203.171.98:8082"; // Backend API

        // Construct full target URL
        let targetURL = `${backendURL}${event.rawPath}`;
        let queryParams = event.rawQueryString ? `?${event.rawQueryString}` : "";

        // Forward request
        const response = await axios({
            method: event.requestContext.http.method,
            url: targetURL + queryParams,
            headers: event.headers,
            data: event.body ? JSON.parse(event.body) : null,
        });

        return {
            statusCode: response.status,
            body: JSON.stringify(response.data),
            headers: {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*",
            }
        };
    } catch (error) {
        return {
            statusCode: error.response?.status || 500,
            body: JSON.stringify({ error: error.message }),
            headers: {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*",
            }
        };
    }
};
